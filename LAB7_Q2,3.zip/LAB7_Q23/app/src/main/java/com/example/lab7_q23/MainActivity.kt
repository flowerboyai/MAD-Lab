package com.example.lab7_q23

import android.graphics.Color
import android.os.Bundle
import android.text.Spannable
import android.text.SpannableString
import android.text.style.BackgroundColorSpan
import android.view.Menu
import android.view.MenuItem
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var imageView: ImageView
    private lateinit var textView: TextView
    private var lastSearchKeyword: String = ""
    private val originalText: String by lazy { getString(R.string.digital_transformation_text) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val toolbar: Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)

        imageView = findViewById(R.id.imageView)
        textView = findViewById(R.id.textView)
        
        textView.text = originalText
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_image_1 -> {
                imageView.setImageResource(android.R.drawable.ic_menu_gallery)
                Toast.makeText(this, "Image - 1: A placeholder for a digital landscape.", Toast.LENGTH_SHORT).show()
                true
            }
            R.id.action_image_2 -> {
                imageView.setImageResource(android.R.drawable.ic_menu_camera)
                Toast.makeText(this, "Image - 2: A placeholder representing modern hardware.", Toast.LENGTH_SHORT).show()
                true
            }
            R.id.action_search -> {
                showSearchDialog()
                true
            }
            R.id.action_highlight -> {
                showHighlightDialog()
                true
            }
            R.id.action_sort -> {
                showSortDialog()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun showSearchDialog() {
        val input = EditText(this)
        AlertDialog.Builder(this)
            .setTitle("Search Keywords")
            .setView(input)
            .setPositiveButton("Search") { _, _ ->
                val keyword = input.text.toString().trim()
                if (keyword.isNotEmpty()) {
                    lastSearchKeyword = keyword
                    if (originalText.contains(keyword, ignoreCase = true)) {
                        Toast.makeText(this, "Keyword '$keyword' found!", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this, "Keyword '$keyword' not found.", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showHighlightDialog() {
        val input = EditText(this)
        AlertDialog.Builder(this)
            .setTitle("Highlight Word")
            .setView(input)
            .setPositiveButton("Highlight") { _, _ ->
                val word = input.text.toString().trim()
                if (word.isNotEmpty()) {
                    highlightText(word)
                }
            }
            .setNegativeButton("Clear Highlight") { _, _ ->
                textView.text = originalText
            }
            .show()
    }

    private fun highlightText(word: String) {
        val spannableString = SpannableString(textView.text)
        val fullText = textView.text.toString().lowercase(Locale.ROOT)
        val searchWord = word.lowercase(Locale.ROOT)
        
        var index = fullText.indexOf(searchWord)
        while (index >= 0) {
            spannableString.setSpan(
                BackgroundColorSpan(Color.YELLOW),
                index,
                index + word.length,
                Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            index = fullText.indexOf(searchWord, index + word.length)
        }
        textView.text = spannableString
    }

    private fun showSortDialog() {
        val options = arrayOf("Alphabetically", "By Relevance to last search")
        AlertDialog.Builder(this)
            .setTitle("Sort Content")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> sortAlphabetically()
                    1 -> sortByRelevance()
                }
            }
            .show()
    }

    private fun sortAlphabetically() {
        val sentences = originalText.split(Regex("(?<=\\.)\\s+")).filter { it.isNotBlank() }
        val sortedText = sentences.sorted().joinToString(" ")
        textView.text = sortedText
    }

    private fun sortByRelevance() {
        if (lastSearchKeyword.isEmpty()) {
            Toast.makeText(this, "Please search for a keyword first.", Toast.LENGTH_SHORT).show()
            return
        }
        val sentences = originalText.split(Regex("(?<=\\.)\\s+")).filter { it.isNotBlank() }
        val sortedText = sentences.sortedByDescending { sentence ->
            sentence.split(" ").count { it.contains(lastSearchKeyword, ignoreCase = true) }
        }.joinToString(" ")
        textView.text = sortedText
    }
}